package com.harindra.iptvpro

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * RAM PLAYER v23.0 — Ultra Master TV Edition Automated Unit Tests.
 */
class RamPlayerV23UltraMasterTest {

    @Test
    fun userAgentProfilesCycleAndRotateCleanly() {
        assertEquals(UserAgentProfile.AUTO_SMART, UserAgentProfile.fromId(null))
        assertEquals(UserAgentProfile.RAM_NATIVE, UserAgentProfile.AUTO_SMART.nextProfile())
        assertEquals(UserAgentProfile.VLC_COMPAT, UserAgentProfile.RAM_NATIVE.nextProfile())

        val ua1 = UserAgentProfile.VLC_COMPAT.userAgentValue
        val ua2 = NetworkClient.nextFallbackUserAgent(ua1)
        assertNotEquals(ua1, ua2)
        assertTrue(ua2.isNotBlank())
    }

    @Test
    fun streamHealthMonitorTracksSessionMetricsAndDetectsExtensionlessUrls() {
        StreamHealthMonitorEngine.resetSession(nowMs = 1_000_000L)
        StreamHealthMonitorEngine.recordZap()
        StreamHealthMonitorEngine.recordZap()
        StreamHealthMonitorEngine.recordRebuffer()
        StreamHealthMonitorEngine.recordAutoRecovery("Extensionless HLS MIME fallback")

        val snap = StreamHealthMonitorEngine.snapshot(nowMs = 1_060_000L)
        assertEquals(60L, snap.sessionDurationSec)
        assertEquals(2, snap.totalZaps)
        assertEquals(1, snap.totalRebuffers)
        assertEquals(1, snap.totalAutoRecoveries)
        assertEquals("Extensionless HLS MIME fallback", snap.lastRecoveredReason)

        assertTrue(StreamHealthMonitorEngine.isExtensionlessHttpStream("http://panel.example:8080/play/12345"))
        assertTrue(StreamHealthMonitorEngine.isExtensionlessHttpStream("https://cdn.example/live/user/pass/901?token=abc"))
        assertFalse(StreamHealthMonitorEngine.isExtensionlessHttpStream("https://cdn.example/live/ch1.m3u8"))
        assertFalse(StreamHealthMonitorEngine.isExtensionlessHttpStream("https://cdn.example/live/ch1.ts"))
        assertFalse(StreamHealthMonitorEngine.isExtensionlessHttpStream("rtsp://192.168.1.2:554/stream"))
    }
}
