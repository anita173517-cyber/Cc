# RAM PLAYER v22.0 — BLACK SCREEN ELIMINATION & ANDROID TV PRO ENGINE

- **Version**: `22.0` (`versionCode = 220`, `applicationId = com.harindra.iptvpro`)
- **Base Foundation**: Upgraded directly on top of `RAM_PLAYER_v21.0_Extreme_Master_FINAL.zip` — zero duplication, all v21.0 & earlier features preserved intact.

## What Was Added & Repaired in v22.0
1. **MPEG-TS / HLS Black-Screen Extractor Fix (`PlayerActivity.kt`)**:
   - Enabled official AndroidX Media3 flags `DefaultTsPayloadReaderFactory.FLAG_ALLOW_NON_IDR_KEYFRAMES | FLAG_DETECT_ACCESS_UNITS` on both `DefaultExtractorsFactory` and `DefaultHlsExtractorFactory`, fixing MPEG-TS and HLS IPTV channels that previously hung on a black screen due to missing AUDs or non-IDR keyframes.
   - Added `setWakeMode(C.WAKE_MODE_NETWORK)` for uninterrupted long playback.
2. **Black-Screen Watchdog & Diagnostics (`BlackScreenDiagnosticsEngine`, `PlayerActivity.kt`)**:
   - Monitors `STATE_READY` with `hasRenderedVideoFrame == false` (3.8s watchdog) and distinguishes Audio-Only streams, missing video tracks, unsupported codecs/10-bit profiles, 4K-on-512MB resolution overflow, decoder init failure, DRM license errors, expired tokens, and renderer stalls.
   - Bounded auto-recovery: disables tunneling if active -> steps down to 720p/4Mbps cap -> tries `backupUrl` -> tries Smart Mirror -> reports exact reason on OSD.
3. **Smart Mirror Auto-Recovery (`SmartMirrorRecoveryEngine`)**:
   - Normalizes channel names (strips HD/FHD/4K/SD/HEVC/Backup/Server 2/country prefixes) to switch automatically to a working alternate stream in the same playlist with loop protection (enabled by default).
4. **Smart Hardware Tunneling & Optional AFR (`Models.kt`, `ProfileStore.kt`, `PlayerActivity.kt`)**:
   - Tunneling modes: `Auto` (default — off on 512MB TVs, safe auto-fallback), `Force On` (with warning), `Off`.
   - Auto Frame-Rate Matching (AFR): `Off` (default to avoid TV black-screen mode-switch flashes during zapping) / `Seamless Only` (`C.VIDEO_CHANGE_FRAME_RATE_STRATEGY_ONLY_IF_SEAMLESS`).
5. **Zero-Dependency SQLite Channel & Dead-Channel Store (`ChannelSqliteStore.kt`)**:
   - Batched SQLite transactions, indexed `(account_scope, category_norm, number)` and `(account_scope, name_norm)` queries, FTS5 runtime probe with indexed `LIKE` fallback, pagination (`queryChannelsPaged`), and separate `dead_channels` table.
6. **Channel Compatibility Scanner & Idle-Time Dead Channel Sweeper (`NetworkClient.kt`, `ChannelScannerEngine`, `PlayerActivity.kt`)**:
   - Lightweight bounded `HEAD` -> 512-byte `GET` probe (never downloads full streams), classifies Alive vs Temp Error vs Auth/Restricted vs Suspected Dead, stores suspected dead channels in SQLite Dead Channels Folder with Restore / Move to Recycle Bin (never auto-deletes).
7. **Optional DNS-over-HTTPS (DoH) & IPv4 Preference (`NetworkClient.kt`, `ProfileStore.kt`)**:
   - `Off (System DNS)` [default], `Cloudflare (1.1.1.1)`, `Google (8.8.8.8)`, plus optional IPv4 address preference and automatic System DNS fallback.
8. **Per-Channel Preferences & Conflict-Free DTH Numeric Zapping (`ProfileStore.kt`, `NumericChannelEntryController`, `PlayerActivity.kt`)**:
   - Per-channel Aspect Ratio & Audio Delay auto-restored on zap.
   - Supports `KEYCODE_0..9` + `KEYCODE_NUMPAD_0..9`, 1.2s auto-confirm, instant OK confirm, and optional `0` Last-Channel recall only when buffer is empty.
9. **Thermal & Memory Survival Mode (`PlayerActivity.kt`)**:
   - Combines existing `onTrimMemory` with API 29+ `PowerManager.currentThermalStatus` to cancel idle sweeps and trim nonessential caches without interrupting active playback.

## Transparent Technical Notes (Skipped / Safely Substituted)
- **Native FFmpeg (`libffmpegJNI.so`)**: Not present in the supplied ZIP and requires native NDK C compilation outside Maven; Media3 `EXTENSION_RENDERER_MODE_ON` + `setEnableDecoderFallback(true)` + Android `MediaCodec` are used without falsely advertising unsupported codecs.
- **Phone-to-TV Local HTTP Server**: Omitted intentionally to avoid adding background server socket/security surface on 512MB TVs; existing M3U/Xtream/Encrypted Backup import remains intact.
- **Physical Device / Gradle Build**: Offline sandbox has no Android SDK; build & unit tests execute automatically in `.github/workflows/build_apk.yml` (Gradle 8.13, SDK 36, JDK 17).
