# RAM PLAYER v23.0 — ULTRA MASTER TV EDITION

- **Version**: `23.0` (`versionCode = 230`, `applicationId = com.harindra.iptvpro`)
- **Base Foundation**: Upgraded directly on top of verified 100%-passing `RAM_PLAYER_v22.0_100_PASS.zip` (all v20/v21/v22 features and startup crash fixes preserved intact, zero features removed).

## New in v23.0 (All Safe Defaults Enabled)
1. **Extensionless Stream Automatic HLS MIME Fallback (`StreamPreFetcher.kt`, `SmartEngineHub.kt`, `PlayerActivity.kt`)**:
   - IPTV servers that serve HLS streams without `.m3u8` in the URL (e.g. `/play/12345`) automatically fall back to `MimeTypes.APPLICATION_M3U8` when progressive parsing fails, fixing `UnrecognizedInputFormatException` channels.
2. **Resilient 5-Retry `DefaultLoadErrorHandlingPolicy` (`PlayerActivity.kt`)**:
   - Applied to both `HlsMediaSource.Factory` and `DefaultMediaSourceFactory` so momentary IPTV CDN segment drops recover seamlessly instead of freezing or dropping to black screen.
3. **Smart User-Agent Profile Selector & One-Shot 403/406 Rotation (`Models.kt`, `NetworkClient.kt`, `ProfileStore.kt`, `PlayerActivity.kt`)**:
   - Choose from `Auto Smart (VLC Compat)` [default], `VLC Media Player`, `Android TV IPTV Compat`, `IPTV Smarters Compat`, `Chrome Android TV`, or `RAM PLAYER v23.0 Native`.
   - In `Auto Smart` mode, HTTP 403/406 triggers one bounded fallback UA retry automatically.
4. **Individual Channel Lock & Kids-Safe Mode (`ProfileStore.kt`, `PlayerActivity.kt`)**:
   - Lock individual channels with your existing Salted SHA-256 4-digit Parental PIN right from Live Channel Management.
   - Toggle Kids-Safe Mode from the Pro Engine Hub.
5. **Live Session Health & Watch-Time Dashboard (`StreamHealthMonitorEngine`, `PlayerActivity.kt`)**:
   - Real measured session uptime, total channels zapped, rebuffer count, auto-recoveries saved, and last recovered reason.
6. **Expanded Automated Tests (`RamPlayerV23UltraMasterTest.kt`)**:
   - Adds unit tests for `UserAgentProfile`, `StreamHealthMonitorEngine`, and extensionless HTTP stream detection (37 total unit tests across 4 test classes).
